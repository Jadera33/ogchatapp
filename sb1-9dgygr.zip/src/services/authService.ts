import Parse from 'parse';

export const authService = {
  async login(email: string, password: string) {
    try {
      const user = await Parse.User.logIn(email, password);
      return user;
    } catch (error) {
      throw error;
    }
  },

  async signup(username: string, email: string, password: string) {
    try {
      const user = new Parse.User();
      user.set("username", username);
      user.set("email", email);
      user.set("password", password);
      await user.signUp();
      return user;
    } catch (error) {
      throw error;
    }
  },

  async resetPassword(email: string) {
    try {
      await Parse.User.requestPasswordReset(email);
    } catch (error) {
      throw error;
    }
  },

  async logout() {
    try {
      await Parse.User.logOut();
    } catch (error) {
      throw error;
    }
  }
};
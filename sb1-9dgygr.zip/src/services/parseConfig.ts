import Parse from 'parse';

export const initializeParse = () => {
  Parse.initialize(
    "YUH6dSIUw3fcjAIint1X1NbTJj4tpjKZQ0YSXnZ4"     // Replace with your Application ID
    "u1gXCi3hCcXDWxL0a7VOYkU6LZV4Mpx8D3ef9gVr"     // Replace with your JavaScript key
    "yWobHSI0hfunEfL3LCkQsiIZTu4OkzxIhJNqOlUP          // Replace with your Master key (optional)
  );
  
  Parse.serverURL = 'https://parseapi.back4app.com/';
};
import Parse from 'parse';

export const chatService = {
  async sendMessage(text: string) {
    try {
      const Message = Parse.Object.extend("Message");
      const message = new Message();
      
      message.set("text", text);
      message.set("sender", Parse.User.current());
      
      await message.save();
      return message;
    } catch (error) {
      throw error;
    }
  },

  subscribeToMessages(callback: (messages: any[]) => void) {
    const query = new Parse.Query("Message");
    query.include("sender");
    query.ascending("createdAt");
    
    const subscription = query.subscribe();
    
    subscription.on('open', () => {
      console.log('Subscription opened');
    });

    subscription.on('create', (message) => {
      callback([message]);
    });

    return () => {
      subscription.unsubscribe();
    };
  }
};
export type MainStackParamList = {
    Login: {};
    Signup: {};
    Chat: {};
};
import * as React from "react";
import { StyleSheet } from "react-nativescript";

interface ErrorMessageProps {
  message: string;
}

export function ErrorMessage({ message }: ErrorMessageProps) {
  return (
    <label style={styles.error}>{message}</label>
  );
}

const styles = StyleSheet.create({
  error: {
    color: "#ff3b30",
    fontSize: 14,
    marginBottom: 10,
    textAlign: "center"
  }
});
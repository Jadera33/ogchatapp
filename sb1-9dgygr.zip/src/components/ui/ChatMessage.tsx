import * as React from "react";
import { StyleSheet } from "react-nativescript";

interface ChatMessageProps {
    message: {
        text: string;
        sender: string;
        timestamp: Date;
    };
    isOwnMessage: boolean;
}

export function ChatMessage({ message, isOwnMessage }: ChatMessageProps) {
    return (
        <flexboxLayout style={[
            styles.messageContainer,
            isOwnMessage ? styles.ownMessage : styles.otherMessage
        ]}>
            <label style={styles.messageText}>{message.text}</label>
            <label style={styles.timestamp}>
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </label>
        </flexboxLayout>
    );
}

const styles = StyleSheet.create({
    messageContainer: {
        padding: 10,
        marginVertical: 5,
        borderRadius: 10,
        maxWidth: "80%",
        flexDirection: "column"
    },
    ownMessage: {
        backgroundColor: "#DCF8C6",
        alignSelf: "flex-end"
    },
    otherMessage: {
        backgroundColor: "white",
        alignSelf: "flex-start"
    },
    messageText: {
        fontSize: 16,
        color: "black"
    },
    timestamp: {
        fontSize: 12,
        color: "#666",
        alignSelf: "flex-end",
        marginTop: 4
    }
});
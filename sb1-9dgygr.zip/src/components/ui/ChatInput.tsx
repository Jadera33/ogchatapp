import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { TextField } from "@nativescript/core";

interface ChatInputProps {
    onSend: (message: string) => void;
}

export function ChatInput({ onSend }: ChatInputProps) {
    const [message, setMessage] = React.useState("");

    const handleSend = () => {
        onSend(message);
        setMessage("");
    };

    return (
        <flexboxLayout style={styles.container}>
            <textField
                style={styles.input}
                hint="Type a message..."
                text={message}
                onTextChange={(args) => {
                    const textField = args.object as TextField;
                    setMessage(textField.text);
                }}
            />
            <button
                style={styles.sendButton}
                text="Send"
                onTap={handleSend}
            />
        </flexboxLayout>
    );
}

const styles = StyleSheet.create({
    container: {
        padding: 10,
        backgroundColor: "white",
        borderTopWidth: 1,
        borderTopColor: "#ddd",
        flexDirection: "row",
        alignItems: "center"
    },
    input: {
        flex: 1,
        marginRight: 10,
        padding: 10,
        backgroundColor: "#f0f0f0",
        borderRadius: 20
    },
    sendButton: {
        backgroundColor: "#0084ff",
        color: "white",
        padding: 10,
        borderRadius: 20,
        minWidth: 70
    }
});
import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { TextField } from "@nativescript/core";

interface AuthInputProps {
    value: string;
    onTextChange: (text: string) => void;
    hint: string;
    secure?: boolean;
    keyboardType?: string;
    style?: any;
}

export function AuthInput({ value, onTextChange, hint, secure = false, keyboardType = "text", style }: AuthInputProps) {
    return (
        <textField
            style={[styles.input, style]}
            hint={hint}
            text={value}
            secure={secure}
            keyboardType={keyboardType}
            onTextChange={(args) => {
                const textField = args.object as TextField;
                onTextChange(textField.text);
            }}
        />
    );
}

const styles = StyleSheet.create({
    input: {
        width: "100%",
        height: 50,
        padding: 10,
        backgroundColor: "#f5f5f5",
        borderRadius: 8,
        fontSize: 16
    }
});
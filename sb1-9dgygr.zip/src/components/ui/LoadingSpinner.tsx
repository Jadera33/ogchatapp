import * as React from "react";
import { ActivityIndicator } from "@nativescript/core";
import { StyleSheet } from "react-nativescript";

interface LoadingSpinnerProps {
  size?: number;
}

export function LoadingSpinner({ size = 32 }: LoadingSpinnerProps) {
  return (
    <activityIndicator
      style={styles.spinner}
      busy={true}
      width={size}
      height={size}
    />
  );
}

const styles = StyleSheet.create({
  spinner: {
    color: "#0084ff"
  }
});
import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { RouteProp } from '@react-navigation/core';
import { FrameNavigationProp } from "react-nativescript-navigation";
import { MainStackParamList } from "../../NavigationParamList";
import { AuthInput } from "../ui/AuthInput";

type SignupScreenProps = {
    route: RouteProp<MainStackParamList, "Signup">,
    navigation: FrameNavigationProp<MainStackParamList, "Signup">,
};

export function SignupScreen({ navigation }: SignupScreenProps) {
    const [username, setUsername] = React.useState("");
    const [email, setEmail] = React.useState("");
    const [password, setPassword] = React.useState("");
    const [confirmPassword, setConfirmPassword] = React.useState("");

    const handleSignup = () => {
        // TODO: Implement actual signup logic
        navigation.navigate("Chat");
    };

    return (
        <flexboxLayout style={styles.container}>
            <label style={styles.title}>Create Account</label>

            <AuthInput
                value={username}
                onTextChange={setUsername}
                hint="Username"
                style={styles.input}
            />

            <AuthInput
                value={email}
                onTextChange={setEmail}
                hint="Email"
                keyboardType="email"
                style={styles.input}
            />

            <AuthInput
                value={password}
                onTextChange={setPassword}
                hint="Password"
                secure={true}
                style={styles.input}
            />

            <AuthInput
                value={confirmPassword}
                onTextChange={setConfirmPassword}
                hint="Confirm Password"
                secure={true}
                style={styles.input}
            />

            <button
                style={styles.signupButton}
                text="Sign Up"
                onTap={handleSignup}
            />

            <button
                style={styles.loginButton}
                text="Already have an account? Login"
                onTap={() => navigation.navigate("Login")}
            />
        </flexboxLayout>
    );
}

const styles = StyleSheet.create({
    container: {
        height: "100%",
        flexDirection: "column",
        backgroundColor: "#ffffff",
        padding: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    title: {
        fontSize: 24,
        fontWeight: "bold",
        marginBottom: 30,
        color: "#333"
    },
    input: {
        marginBottom: 15
    },
    signupButton: {
        backgroundColor: "#0084ff",
        color: "white",
        width: "100%",
        padding: 15,
        borderRadius: 8,
        marginTop: 20,
        fontWeight: "bold"
    },
    loginButton: {
        marginTop: 15,
        color: "#0084ff",
        backgroundColor: "transparent"
    }
});
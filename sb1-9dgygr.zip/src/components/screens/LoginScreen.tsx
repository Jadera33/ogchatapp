import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { RouteProp } from '@react-navigation/core';
import { FrameNavigationProp } from "react-nativescript-navigation";
import { MainStackParamList } from "../../NavigationParamList";
import { TextField } from "@nativescript/core";
import { AuthInput } from "../ui/AuthInput";

type LoginScreenProps = {
    route: RouteProp<MainStackParamList, "Login">,
    navigation: FrameNavigationProp<MainStackParamList, "Login">,
};

export function LoginScreen({ navigation }: LoginScreenProps) {
    const [email, setEmail] = React.useState("");
    const [password, setPassword] = React.useState("");

    const handleLogin = () => {
        // TODO: Implement actual login logic
        navigation.navigate("Chat");
    };

    return (
        <flexboxLayout style={styles.container}>
            <label style={styles.title}>Welcome Back!</label>
            
            <AuthInput
                value={email}
                onTextChange={setEmail}
                hint="Email"
                keyboardType="email"
                style={styles.input}
            />

            <AuthInput
                value={password}
                onTextChange={setPassword}
                hint="Password"
                secure={true}
                style={styles.input}
            />

            <button
                style={styles.loginButton}
                text="Login"
                onTap={handleLogin}
            />

            <button
                style={styles.signupButton}
                text="Don't have an account? Sign up"
                onTap={() => navigation.navigate("Signup")}
            />
        </flexboxLayout>
    );
}

const styles = StyleSheet.create({
    container: {
        height: "100%",
        flexDirection: "column",
        backgroundColor: "#ffffff",
        padding: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    title: {
        fontSize: 24,
        fontWeight: "bold",
        marginBottom: 30,
        color: "#333"
    },
    input: {
        marginBottom: 15
    },
    loginButton: {
        backgroundColor: "#0084ff",
        color: "white",
        width: "100%",
        padding: 15,
        borderRadius: 8,
        marginTop: 20,
        fontWeight: "bold"
    },
    signupButton: {
        marginTop: 15,
        color: "#0084ff",
        backgroundColor: "transparent"
    }
});
import * as React from "react";
import { StyleSheet } from "react-nativescript";
import { RouteProp } from '@react-navigation/core';
import { FrameNavigationProp } from "react-nativescript-navigation";
import { MainStackParamList } from "../../NavigationParamList";
import { ChatMessage } from "../ui/ChatMessage";
import { ChatInput } from "../ui/ChatInput";
import { ScrollView, TextField } from "@nativescript/core";

type ChatScreenProps = {
    route: RouteProp<MainStackParamList, "Chat">,
    navigation: FrameNavigationProp<MainStackParamList, "Chat">,
};

export function ChatScreen({ navigation }: ChatScreenProps) {
    const [messages, setMessages] = React.useState([
        { id: 1, text: "Hello!", sender: "user1", timestamp: new Date() },
        { id: 2, text: "Hi there!", sender: "user2", timestamp: new Date() }
    ]);

    const handleSend = (message: string) => {
        if (message.trim()) {
            setMessages([
                ...messages,
                {
                    id: messages.length + 1,
                    text: message,
                    sender: "user1",
                    timestamp: new Date()
                }
            ]);
        }
    };

    return (
        <flexboxLayout style={styles.container}>
            <ScrollView style={styles.messageList}>
                <stackLayout>
                    {messages.map((message) => (
                        <ChatMessage
                            key={message.id}
                            message={message}
                            isOwnMessage={message.sender === "user1"}
                        />
                    ))}
                </stackLayout>
            </ScrollView>
            <ChatInput onSend={handleSend} />
        </flexboxLayout>
    );
}

const styles = StyleSheet.create({
    container: {
        height: "100%",
        flexDirection: "column",
        backgroundColor: "#f5f5f5"
    },
    messageList: {
        flex: 1,
        padding: 10
    }
});
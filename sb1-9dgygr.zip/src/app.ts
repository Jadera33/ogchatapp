import * as React from 'react';
import * as ReactNativeScript from 'react-nativescript';
import { MainStack } from './components/MainStack';
import { initializeParse } from './services/parseConfig';

Object.defineProperty(global, '__DEV__', { value: false });

// Initialize Parse
initializeParse();

ReactNativeScript.start(React.createElement(MainStack, {}, null));